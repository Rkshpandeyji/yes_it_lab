<?php

use App\Http\Controllers\AudioController;
use App\Http\Controllers\ProductAjaxController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/latlong', function () {
    return view('latlongForm');
});

Route::resource('products-ajax-crud', ProductAjaxController::class);
Route::post('/get-audio-length', [AudioController::class, 'getLength'])->name('get-audio-length');
Route::get('/get-audio-length', [AudioController::class, 'showForm'])->name('get-audio-length-form');
Route::get('/calculate-distance', [AudioController::class, 'calculateDistance'])->name('calculate-distance');

// routes/web.php

Route::get('users/export-csv', [ProductAjaxController::class, 'exportCsv'])->name('users.export-csv');



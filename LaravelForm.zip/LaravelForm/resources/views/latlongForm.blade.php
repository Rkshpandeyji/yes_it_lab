<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculate Distance</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom styles here */
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1>Calculate Distance</h1>
        <div class="row">
            <div class="col-md-6">
                <label for="lat1">Latitude 1:</label>
                <input type="text" id="lat1" name="lat1" class="form-control mb-3">
            </div>
            <div class="col-md-6">
                <label for="lng1">Longitude 1:</label>
                <input type="text" id="lng1" name="lng1" class="form-control mb-3">
            </div>
            <div class="col-md-6">
                <label for="lat2">Latitude 2:</label>
                <input type="text" id="lat2" name="lat2" class="form-control mb-3">
            </div>
            <div class="col-md-6">
                <label for="lng2">Longitude 2:</label>
                <input type="text" id="lng2" name="lng2" class="form-control mb-3">
            </div>
        </div>
        <button onclick="calculateDistance()" class="btn btn-primary">Calculate Distance</button>
        <div id="result" class="mt-3"></div>
    </div>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
          function calculateDistance() {
            const lat1 = parseFloat(document.getElementById('lat1').value);
            const lng1 = parseFloat(document.getElementById('lng1').value);
            const lat2 = parseFloat(document.getElementById('lat2').value);
            const lng2 = parseFloat(document.getElementById('lng2').value);

            fetch(`/calculate-distance?lat1=${lat1}&lng1=${lng1}&lat2=${lat2}&lng2=${lng2}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('result').innerText = `Distance: ${data.distance.toFixed(2)} km`;
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>

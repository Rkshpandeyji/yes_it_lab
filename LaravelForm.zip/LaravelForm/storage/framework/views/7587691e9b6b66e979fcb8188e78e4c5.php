<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Audio Length</title>
</head>
<body>
    <input type="file" id="audioFileInput">
    <button onclick="getAudioLength()">Get Audio Length</button>
    <div id="playTime"></div>

    <script>
        function getAudioLength() {
            const fileInput = document.getElementById('audioFileInput');
            const file = fileInput.files[0];

            if (!file) {
                alert('Please select an audio file.');
                return;
            }

            const formData = new FormData();
            formData.append('audio_file', file);

            fetch('/get-audio-length', {
                method: 'post',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.play_time) {
                    document.getElementById('playTime').innerText = `Play Time: ${data.play_time}`;
                } else {
                    alert(data.error);
                }
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\LaravelForm\resources\views/welcome.blade.php ENDPATH**/ ?>
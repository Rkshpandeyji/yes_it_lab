<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Audio File</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            padding: 40px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">Upload Audio File</h1>
        <form action="<?php echo e(route('get-audio-length')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="audioFile">Choose an audio file:</label>
                <input type="file" class="form-control-file" id="audioFile" name="audio_file" accept="audio/*">
            </div>
            <button type="submit" class="btn btn-primary">Get Audio Length</button>
        </form>
    </div>

    <!-- Bootstrap JS and jQuery (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\LaravelForm\resources\views/audio/upload_form.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Yajra\DataTables\Facades\DataTables;

class ProductAjaxController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        if ($request->ajax()) {

            $data = User::latest()->get();

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {

                    $btn = '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-primary btn-sm editProduct">Edit</a>';

                    $btn = $btn . ' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Delete" class="btn btn-danger btn-sm deleteProduct">Delete</a>';

                    return $btn;
                })
                ->addColumn('image', function ($row) {
                    $img = '<img src="' . asset($row->profile_pic) . '" alt="Image" class="img-thumbnail" width="100">';
                    return $img;
                })
                ->rawColumns(['action','image'])
                ->make(true);
        }

        return view('productAjax');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        if($request->user_id == null)
        {
            $validator = Validator::make($request->all(), [
                'name' => 'required|regex:/^[a-zA-Z\s]+$/',
                'email' => 'required|email|unique:users,email',
                'mobile_no' => 'required|digits:10|unique:users,mobile_no',
                'profile_pic' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
                'password' => 'required|min:6',
            ]);
            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()->toArray()]);
            }
        }
        
        
        

        $profilePicPath = null;

        if ($request->hasFile('profile_pic')) {
            $profilePic = $request->file('profile_pic');
            // $profilePicPath = $profilePic->store('profile_pics', 'public'); // Store profile pic in storage/app/public/profile_pics folder
            $profilePicName = time() . '_' . $profilePic->getClientOriginalName();

            // Move the uploaded file to the desired directory
            $profilePic->move(public_path('profile_pics'), $profilePicName);
            
            // Construct the image path
            $profilePicPath = 'profile_pics/' . $profilePicName;
            }

        $user = User::updateOrCreate(
            ['id' => $request->user_id],
            [
                'name' => $request->name,
                'email' => $request->email,
                'mobile_no' => $request->mobile_no,
                'profile_pic' => $profilePicPath,
                'password' => md5($request->password)
            ]
        );

        return response()->json(['success' => 'User saved successfully.']);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * 
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = User::find($id);
        return response()->json($product);
    }

    /**
     * Remove the specified resource from storage.
     *
     * 
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::find($id)->delete();

        return response()->json(['success' => 'User deleted successfully.']);
    }
    public function exportCsv()
    {
        $users = User::all();

        $filename = 'users.csv';
        $headers = array(
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$filename",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        );

        $handle = fopen('php://output', 'w');
        fputcsv($handle, ['ID', 'Name', 'Email', 'Mobile No.', 'Profile Pic']);

        foreach ($users as $user) {
            fputcsv($handle, [
                $user->id,
                $user->name,
                $user->email,
                $user->mobile_no,
                $user->profile_pic,
            ]);
        }

        fclose($handle);

        return Response::make(file_get_contents('php://output'), 200, $headers);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use getID3;

class AudioController extends Controller
{
    public function getLength(Request $request)
    {
        $file = $request->file('audio_file');

        // Check if file is audio
        if ($file->getMimeType() === 'audio/mpeg') {
            $getID3 = new \getID3;
            $fileInfo = $getID3->analyze($file);
            $playTime = $fileInfo['playtime_string'];

            return response()->json(['play_time' => $playTime]);
        } else {
            return response()->json(['error' => 'Uploaded file is not an audio file'], 400);
        }
    }
    public function showForm()
    {
        return view('audio.upload_form');
    }
    public function calculateDistance(Request $request)
    {
        $lat1 = $request->input('lat1');
        $lng1 = $request->input('lng1');
        $lat2 = $request->input('lat2');
        $lng2 = $request->input('lng2');

        $earthRadius = 6371; // Radius of the Earth in kilometers

        $latFrom = deg2rad($lat1);
        $lngFrom = deg2rad($lng1);
        $latTo = deg2rad($lat2);
        $lngTo = deg2rad($lng2);

        $latDelta = $latTo - $latFrom;
        $lngDelta = $lngTo - $lngFrom;

        $distance = 2 * $earthRadius * asin(sqrt(pow(sin($latDelta / 2), 2) + cos($latFrom) * cos($latTo) * pow(sin($lngDelta / 2), 2)));

        return response()->json(['distance' => $distance]);
    }
}
